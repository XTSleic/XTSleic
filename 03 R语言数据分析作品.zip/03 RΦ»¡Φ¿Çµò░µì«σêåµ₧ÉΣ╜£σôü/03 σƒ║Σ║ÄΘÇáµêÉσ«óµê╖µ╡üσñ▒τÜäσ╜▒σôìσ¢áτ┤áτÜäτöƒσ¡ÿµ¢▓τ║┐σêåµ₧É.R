# Library packages
library(dplyr)
library(pscl)
library(survival)
library(ggplot2)
library(ggfortify)
library(tidyr)

# Load dataset
churn =  read.csv('https://dxl-datasets.s3.amazonaws.com/mas646/telcoChurn.csv')
churn$tenure = as.numeric(churn$tenure)
churn$Churn=factor(churn$Churn)
churn$Churn2 = ifelse(churn$Churn=='Yes', 1, 0)
newv = churn


######################
#Descriptive analysis#
######################

ggplot(data = churn, aes(MonthlyCharges)) + 
  geom_histogram(color = 'black',fill="sky blue")

churn %>% 
  select(Contract,SeniorCitizen,Partner,Dependents,PaymentMethod)%>%
  mutate(SeniorCitizen = as.factor(SeniorCitizen))%>%
  gather() %>% 
  ggplot(aes(value)) +
  facet_wrap(~ key, scales = "free") +
  geom_bar(color = 'black',fill="sky blue") +
  theme(axis.text.x = element_text(angle = 15))


###################
#Fit overall model#
###################

# km-sample
kms = survfit(Surv(tenure, Churn2) ~ 1, data=churn)
plot(kms, xlab='Customer stay time in month', 
     ylab='Survival Probability', conf.int=F)

# Churn2 is a problem, when customers stay for more than 70 months, 
# about 40 percent of them will leave.

##############################
#Fit model and interpretation#
##############################

#——---------------------------------------------------------------------------------------------------
# gender of customer
table(churn$gender)
autoplot(survfit(Surv(tenure, Churn2) ~ gender, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~  gender , data=churn)
m
survdiff(Surv(tenure, Churn2) ~ gender, data=churn)
# p= 0.5, suggest survival curves equivalent across gender of customer.
# genderMale: Hazard Ratio = 0.97 -> 
# "for male customer, their prob of left decrease 3% compared with female customer.

km = survfit(Surv(tenure, Churn2) ~ gender, data=churn)
print(km, print.rmean=T, rmean=72)
#     Female = rmean = 54.1 -> "of the next 72 month, I expect customer to be here for 54.1 of the 72 month"
#     Male  = rmean = 54.9 -> "of the next 72 month, I expect customer to be here for 54.9 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# SeniorCitizen
table(churn$SeniorCitizen)
autoplot(survfit(Surv(tenure, Churn2) ~  SeniorCitizen, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~ SeniorCitizen , data=churn)
m
survdiff(Surv(tenure, Churn2) ~ SeniorCitizen, data=churn)
# p= <2e-16, suggest survival curves not equivalent across if customer is a senior citizen.
# SeniorCitizen: Hazard Ratio = 1.73 -> 
# "for senior citizen customer, their prob of left increase 73% compared with no dependents customer".

km = survfit(Surv(tenure, Churn2) ~ SeniorCitizen, data=churn)
print(km, print.rmean=T, rmean=72)
#     not SeniorCitizen = rmean = 56.1 -> "of the next 72 month, I expect customer to be here for 56.1 of the 72 month"
#     SeniorCitizen = rmean = 47.4 -> "of the next 72 month, I expect customer to be here for 47.4 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# Partner
table(churn$Partner)
autoplot(survfit(Surv(tenure, Churn2) ~  Partner, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~  Partner, data=churn)
m
survdiff(Surv(tenure, Churn2) ~ SeniorCitizen, data=churn)
# p= <2e-16, suggest survival curves not equivalent across if customer has a partner.
# PartnerYes: Hazard Ratio = 0.38 -> 
# "for customer with partner, their prob of left decrease 62% compared with no partner customer".

km = survfit(Surv(tenure, Churn2) ~ Partner, data=churn)
print(km, print.rmean=T, rmean=72)
#     No Partner = rmean = 47.0 -> "of the next 72 month, I expect customer to be here for 47.0 of the 72 month"
#     With Partner = rmean = 61.3 -> "of the next 72 month, I expect customer to be here for 61.3 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# Dependents
table(churn$Dependents)
autoplot(survfit(Surv(tenure, Churn2) ~ Dependents, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~ Dependents, data=churn)
m
survdiff(Surv(tenure, Churn2) ~ SeniorCitizen, data=churn)
# p= <2e-16, suggest survival curves not equivalent across if customer has dependents.
# DependentsYes: Hazard Ratio = 0.41 -> 
# "for customer with dependents, their prob of left decrease 59% compared with no dependents customer".

km = survfit(Surv(tenure, Churn2) ~ Dependents, data=churn)
print(km, print.rmean=T, rmean=72)
#     No Dependents = rmean = 50.9 -> "of the next 72 month, I expect customer to be here for 50.9 of the 72 month"
#     With Dependents = rmean = 62.5 -> "of the next 72 month, I expect customer to be here for 62.5 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# Contract
table(churn$Contract)
autoplot(survfit(Surv(tenure, Churn2) ~ Contract, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~ MonthlyCharges + Contract, data=churn)
m
survdiff(Surv(tenure, Churn2) ~ Contract, data=churn) 
# p= <2e-16, suggest survival curves equivalent across customers contract length.
# ContractOne year: Hazard Ratio = 0.11 -> 
# "for customer with dependents, their prob of left decrease 89% compared with month to month contract".
# ContractTwo year: Hazard Ratio = 0.01 -> 
# "for customer with dependents, their prob of left decrease 99% compared with month to month contract".

km = survfit(Surv(tenure, Churn2) ~ Contract, data=churn)
print(km, print.rmean=T, rmean=72)
#     Month-to-month = rmean = 36.3 -> "of the next 72 month, I expect customer to be here for 36.3 of the 72 month"
#     One year = rmean = 66.4 -> "of the next 72 month, I expect customer to be here for 66.4 of the 72 month"
#     Two year = rmean = 71.5 -> "of the next 72 month, I expect customer to be here for 71.5 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# PaperlessBilling
table(churn$PaperlessBilling)
autoplot(survfit(Surv(tenure, Churn2) ~ PaperlessBilling, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
m = coxph(Surv(tenure, Churn2) ~ PaperlessBilling, data=churn)
m
survdiff(Surv(tenure, Churn2) ~ PaperlessBilling, data=churn) 
# p= <2e-16, suggest survival curves not equivalent across if customer signed up for paperless billing.
# PaperlessBillingYes: Hazard Ratio = 2.05 -> 
# "for customer with paperless billing, their prob of left increase 105% compared with no paperless billing customer".

km = survfit(Surv(tenure, Churn2) ~ PaperlessBilling, data=churn)
print(km, print.rmean=T, rmean=72)
#     No PaperlessBilling = rmean = 60.6 -> "of the next 72 month, I expect customer to be here for 60.6 of the 72 month"
#     With PaperlessBilling = rmean = 50.8 -> "of the next 72 month, I expect customer to be here for 50.8 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# PaymentMethod
table(churn$PaymentMethod)
autoplot(survfit(Surv(tenure, Churn2) ~ PaymentMethod, data=churn), conf.int = F, censor = F,
         xlab='Customer stay time in month', ylab='Survival Probability')
# Combine category 'No' and 'No phone service'
churn$PaymentMethodNew = ifelse(churn$PaymentMethod == 'Credit card (automatic)', 'Automatic check', 
                                    ifelse(churn$PaymentMethod == 'Bank transfer (automatic)', 'Automatic check', churn$PaymentMethod))
m = coxph(Surv(tenure, Churn2) ~ PaymentMethodNew, data=churn)
m
survdiff(Surv(tenure, Churn2) ~ PaymentMethod, data=churn) 
# p= <2e-16, suggest survival curves not equivalent across customers method of payment.
# Electronic check: Hazard Ratio = 4.42 -> 
# "for customer with electronic check, their prob of left increase 342% compared with automatic check".
# Mailed check: Hazard Ratio = 2.06 -> 
# "for customer with Mailed check, their prob of left increase 106% compared with automatic check".

km = survfit(Surv(tenure, Churn2) ~ PaymentMethodNew, data=churn)
print(km, print.rmean=T, rmean=72)
#     Automatic check = rmean = 63.4 -> "of the next 72 month, I expect customer to be here for 63.4 of the 72 month"
#     Electronic check = rmean = 41.2 -> "of the next 72 month, I expect customer to be here for 41.2 of the 72 month"
#     Mailed check = rmean = 56.4 -> "of the next 72 month, I expect customer to be here for 56.4 of the 72 month"


#——---------------------------------------------------------------------------------------------------
# MonthlyCharges
m = coxph(Surv(tenure, Churn2) ~ MonthlyCharges, data=churn)
m
# MonthlyCharges: Hazard Ratio = 1.0061772 -> 
# "for each additonal $10 in monthly charges, customer's prob of left increase 6.3% 


#——---------------------------------------------------------------------------------------------------
# Internet Service
churn$Churn=factor(churn$Churn)

#   1. Generate km curves for InternetService
kmis=survfit(Surv(tenure,Churn2)~InternetService,data=churn)
autoplot(kmis,conf.int=F,censor=F)
#   CONCLUSION: Estimates survival probabilities over period of time vary whether having InternetService or not 

#   2. Test for difference in survival functions by stage
survdiff(Surv(tenure,Churn2)~InternetService,data=churn)
#     H0: Survival curves equivalent whether having InternetService or not 
#     HA: Survival curves NOT equivalent whether having InternetService or not 
#     p-value=<2e-16 --> reject H0
#     CONCLUSION: survival curves are not equivalent whether having InternetService or not --> it is necessary to stratify InternetService later

print(survfit(Surv(tenure,Churn2)~InternetService,data=churn), print.rmean = T, rmean = 72)
#     CONCLUSION: Restricted mean survival times vary whether having InternetService or not 

#   3. Use Cox regression, so we can adjust for other sub covariates
#   OnlineSecurity" "OnlineBackup"  "DeviceProtection" "TechSupport" "StreamingTV" "StreamingMovies"
coxis=coxph(Surv(tenure,Churn2)~InternetService+OnlineSecurity+OnlineBackup+DeviceProtection+TechSupport+StreamingTV+StreamingMovies,data=churn)
coxis
autoplot(survfit(coxis),conf.int=F,censor=F)
##    What is the most important covariates to hazard ratio of churned? --> InternetService
##    --> exp(coef(internet-Fiber optic))=1.571 --> hazard ratio of churned increases 57% 
##    --> exp(coef(No internet))=0.074  --> hazard ratio of decreases 92 % 
##    --> exp(coef(other sub services))<1  --> decrease hazard ratio
#     CONCLUSION: Intenet service negatively impacts on customer retention (we might look for better service partner)

#   4. Check proportional hazards 
#       H0: Proportional hazards assumption holds
#       Ha: Proportional hazards assumption violated
cox.zph(coxis)
## all p-value significant  --> reject H0 ---> all predictors do not decrease proportionally/constantly
## chisq(InternetService) is the highest --> stratify on InternetService
coxiss=coxph(Surv(tenure,Churn2)~strata(InternetService)+OnlineSecurity+OnlineBackup+DeviceProtection+TechSupport+StreamingTV+StreamingMovies,data=churn)
coxiss
autoplot(survfit(coxiss),conf.int=F,censor=F)
#     CONCLUSION 1：For customers with no internet service, the expected survival rate is over 80% and the survival curve drop slowly and constantly over period of time
#     CONCLUSION 2：For customers with DSL and FO, the expected survival rate are below 15% and curves drop rapidly in the first year.
#     CONCLUSION 3：For customers with FO, the expected survival is worse than that with DSL.

#   5. Further finding
coxis
##    --> exp(coef(other sub services))<1  --> decrease hazard ratio
## If customers have internet service, the more services they pay, the less hazard ratio of churned would be
## we define 'internetindex'--> factorize the number of service customer have
c=churn
c$OnlineSecurity=ifelse(c$InternetService=='No',-1,ifelse(c$OnlineSecurity=='Yes',1,0))
c$OnlineBackup=ifelse(c$InternetService=='No',-1,ifelse(c$OnlineBackup=='Yes',1,0))
c$DeviceProtection=ifelse(c$InternetService=='No',-1,ifelse(c$DeviceProtection=='Yes',1,0))
c$TechSupport=ifelse(c$InternetService=='No',-1,ifelse(c$TechSupport=='Yes',1,0))
c$StreamingTV=ifelse(c$InternetService=='No',-1,ifelse(c$StreamingTV=='Yes',1,0))
c$StreamingMovies=ifelse(c$InternetService=='No',-1,ifelse(c$StreamingMovies=='Yes',1,0))

c$OnlineSecurity=as.numeric(c$OnlineSecurity)
c$OnlineBackup=as.numeric(c$OnlineBackup)
c$DeviceProtection=as.numeric(c$DeviceProtection)
c$TechSupport=as.numeric(c$TechSupport)
c$StreamingTV=as.numeric(c$StreamingTV)
c$StreamingMovies=as.numeric(c$StreamingMovies)

c$internetindex=ifelse(c$InternetService=='No','None',as.character(c$OnlineSecurity+c$OnlineBackup+c$DeviceProtection+c$TechSupport+c$StreamingTV+c$StreamingMovies))
c$internetindex=factor(c$internetindex)
## scales in internetindex: None, 1, 2, 3, 4....

#   5.1 cox regression on internetindex
coxid=coxph(Surv(tenure,Churn2)~internetindex,data=c)
coxid
autoplot(survfit(coxph(Surv(tenure,Churn2)~strata(internetindex),data=c)),conf.int=F,censor=F)

#   5.2 Restricted Mean Survival Time for internetindex
print(survfit(Surv(tenure,Churn2)~internetindex,data=c), print.rmean = T, rmean = 72)

#   conclusion 1: For customers with internet service, the more services they subscribe, the less hazard ratio of churned would be.
#   conclusion 2: Comparing to customers with no internet service, the survival rate is even better for those with 5 or 6 services.
#   conclusion 3: The restricted mean survival time 
plot(c$internetindex,c$TotalCharges)


#——---------------------------------------------------------------------------------------------------
# Phone Service
#   1. Generate km curves for PhoneService
kmps=survfit(Surv(tenure,Churn2)~PhoneService,data=churn)
autoplot(kmps,conf.int=F,censor=F)
#   CONCLUSION: Estimates survival probabilities over period of time do not vary whether having PhoneService or not 

#   2. Test for difference in survival functions by stage
survdiff(Surv(tenure,Churn2)~PhoneService,data=churn)
#     H0: Survival curves equivalent whether having PhoneService or not 
#     HA: Survival curves NOT equivalent whether having PhoneService or not 
#     p-value=0.5 --> fail to reject H0
#     CONCLUSION: survival curves are equivalent whether having PhoneService or not --> it is not necessary to stratify PhoneService later
print(survfit(Surv(tenure,Churn2)~PhoneService,data=c), print.rmean = T, rmean = 72)

#   3. Use Cox regression, so we can adjust for other sub covariates
#   ”MultipleLines" 
coxps=coxph(Surv(tenure,Churn2)~PhoneService+MultipleLines,data=churn)
coxps
autoplot(survfit(coxps),conf.int=F,censor=F)
##   exp(coef(PhoneServiceYes))=1.22 --> increase 22% hazard ratio but not statistically significant
##   exp(coef(MultipleLinesYes))=0.76  --> decrease 24% hazard ratio
#    CONCLUSION: Phone service negatively impacts on customer retention (we might look for better service partner)

#   4. Check proportional hazards 
#       H0: Proportional hazards assumption holds
#       Ha: Proportional hazards assumption violated
cox.zph(coxps)
# p-value(MultipleLines)<2e-16  --> reject H0 ---> MultipleLines do not decrease proportionally/constantly
##  stratify on MultipleLines
coxpsm=coxph(Surv(tenure,Churn2)~strata(MultipleLines)+PhoneService,data=churn)
coxpsm
autoplot(survfit(coxpsm),conf.int=F,censor=F)

# 5. Restricted Mean Survival Time 
print(survfit(Surv(tenure,Churn2)~PhoneService+MultipleLines,data=churn), print.rmean = T, rmean = 72)


##########
#Strategy#
##########

# 1. PLACE: 
  # Increasing marketing efforts to non-senior citizens and customers with partners and dependents. For example, offering certain promotions.
  # Discount for customers who are willing to sign a two-year contract.
  # Cooperate with credit card companies to give customers who are willing to use credit card and bank transfer benefits, such as account rebates.

# 2. PRICE: 
  # Give discounts to customers who spend more than the average amount per month

# 3. PRODUCT: 
  # Stop the current service, and find better business partners

# 4. PROMOTION: 
  # Service promotions (BOGO FREE) 














