# GROUP MEMBER:
#	LEI CHEN / C23742132
#   HONGTAO WANG / C23701651


CREATE DATABASE FoodOrder;
USE FoodOrder;


-- Step 1: Create Tables

CREATE TABLE customers (
  id 					INT 			PRIMARY KEY AUTO_INCREMENT,
  fullname 				VARCHAR(255) 	NOT NULL,
  address 				VARCHAR(255) 	NOT NULL,
  phone_num 			VARCHAR(255)	NOT NULL	UNIQUE,
  prefered_paymethod	INT				NOT NULL,
  payment_due 			DECIMAL(6, 2) 	NOT NULL 	DEFAULT 0,
  member_since 			TIMESTAMP 		NOT NULL 	DEFAULT NOW()
);

CREATE TABLE stores (
  id 			INT 			PRIMARY KEY AUTO_INCREMENT,
  store_name 	VARCHAR(255) 	NOT NULL,
  category 		VARCHAR(255),
  address 		VARCHAR(255) 	NOT NULL,
  phone_num 	VARCHAR(255) 	NOT NULL	UNIQUE
);

CREATE TABLE food (
  id 			INT 			PRIMARY KEY AUTO_INCREMENT,
  store_id 		INT 			NOT NULL,
  food_name 	VARCHAR(255) 	NOT NULL,
  price 		DECIMAL(6, 2) 	NOT NULL,
  ingredients 	VARCHAR(255),
  CONSTRAINT fk1 FOREIGN KEY (store_id) REFERENCES stores (id)
);

CREATE TABLE payment_method (
	id			INT				PRIMARY KEY AUTO_INCREMENT,
    method		VARCHAR(255)	NOT NULL	
);

CREATE TABLE order_status (
	id			INT				PRIMARY KEY AUTO_INCREMENT,
    status		VARCHAR(255)	NOT NULL

);

CREATE TABLE orders (
  id					INT 			PRIMARY KEY AUTO_INCREMENT,
  customer_id 			INT 			NOT NULL,
  food_id 				INT 			NOT NULL,
  quantity 				INT 			NOT NULL 	DEFAULT 1,
  order_time 			TIMESTAMP 		NOT NULL 	DEFAULT NOW(),
  status_id				INT			 	NOT NULL	DEFAULT 1,
  CONSTRAINT fk2 FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk3 FOREIGN KEY (food_id) REFERENCES food (id),
  CONSTRAINT fk4 FOREIGN KEY (status_id) REFERENCES order_status (id)
);

-- Step 2: Insert data into tables 

-- INSERT INTO customers
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Bessie Smith', '22 Warren St New York, NY', '212-554-1511', 1);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Rosa Johnson', '801 2nd Ave New York, NY', '212-889-0903', 1);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Elizabeth Williams', '458 9th Avet New York, NY', '212-823-9332', 2);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Marie Brown', '233 Broadway New York, NY', '212-288-0031', 2);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Minnie Jones', '302 E 12th S New York, NY', '212-254-3502', 3);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Hattie Miller', '440 Park Ave S New York, NY', '212-477-0775', 3);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Alice Davis', '584 Amsterdam Ave New York, NY', '212-299-3901', 1);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Thelma Garcia', '478 South St New York, NY', '212-475-5822', 2);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Nellie Rodriguez', '363 W 46th St New York, NY', '212-497-8093', 2);
INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES ('Margaret Wilson', '1260 Amsterdam Ave New York, NY', '212-539-1776', 3);

-- INSERT INTO stores
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Le Petit Souffle', 'French, Japanese, Desserts', '53 Great Jones Street New York, NY 10012', '212-124-9411'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Izakaya Kikufuji', 'Japanese', '1170 Broadway，New York, NY 10001', '212-813-3214'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Heat - Edsa Shangri-La', 'Seafood, Asian, Filipino, Indian', '75 Washington Place ，New York, NY 10011', '212-139-2342'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Ooma', 'Japanese, Sushi', '110 Waverly Place，New York, NY 10011 ', '212-942-5463'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Sambo Kojin', 'Japanese, Korean', '12 E 12th St ，New York, NY 10003', '212-131-8665'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Din Tai Fung', 'Chinese', '85 10th Ave ，New York, NY 10011', '212-954-3493'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Buffet 101', 'Asian, European', '35 East 18th Street ，New York, NY 10003', '212-582-9563'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Vikings', 'Seafood, Filipino, Asian, European', 'Central Park West，New York, NY 10023', '212-532-7842'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Spiral - Sofitel Philippine Plaza Manila', 'European, Asian, Indian', '42 East 20th Street New York, NY 10003', '212-953-9523'); 
INSERT INTO stores (store_name, category, address, phone_num) VALUES ('Locavore', 'Filipino', '163 1st Ave，New York, NY 10003 ', '212-394-5864'); 

-- INSERT INTO food
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Tandoori Mixed Grill', 15.8, 'Beef');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Mushroom Rice', 12.95, 'Mushroom');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Garlic Naan', 2.95, 'Garlic/Wheat');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Paratha', 3.95, 'Wheat');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Meat Samosa', 8.95, 'Pork');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (1, 'Prawn Puree', 12.5, 'Shrimp');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (4, 'Lamb Tikka Chilli Masala', 13.6, 'Lamb');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (4, 'Mango Chutney', 3.95, 'Mango');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (4, 'French Fries', 4.95, 'Potato');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (4, 'Chicken Tikka Biryani', 7.95, 'Chicken');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (4, 'Lamb Tikka Biryani', 1.95, 'Lamb');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (6, 'Prawn Balti', 4.95, 'Shrimp');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (6, 'Tandoori Fish', 5.95, 'Fish');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (6, 'Lamb Tikka Balti', 14.95, 'Lamb');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (8, 'Chicken Tikka Balti', 5.95, 'Chicken');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (8, 'Chicken Roshni', 9.95, 'Chicken');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (8, 'Lamb Roshni', 13.95, 'Lamb');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (8, 'Chicken Shashlick Curry', 9.95, 'Chicken');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (10, 'Prawn Biryani', 3.95, 'Shrimp');
INSERT INTO food (store_id, food_name, price, ingredients) VALUES (10, 'Lamb Shashlick Curry', 3.95, 'Lamb');


-- INSERT INTO payment_method
INSERT INTO payment_method (method) VALUES ('Cash');
INSERT INTO payment_method (method) VALUES ('Credit Card');
INSERT INTO payment_method (method) VALUES ('Debit Card');

-- INSERT INTO order_status
INSERT INTO order_status (status) VALUES ('Accepted');
INSERT INTO order_status (status) VALUES ('Cooking');
INSERT INTO order_status (status) VALUES ('Delivering');
INSERT INTO order_status (status) VALUES ('Delivered');
INSERT INTO order_status (status) VALUES ('Canceled');

-- INSERT INTO orders
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 1, 2, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 4, 1, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (6, 7, 2, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (6, 8, 3, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (6, 9, 4, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (6, 10, 1, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (9, 15, 2, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (9, 16, 2, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (9, 17, 3, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (9, 18, 1, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 8, 4, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 9, 1, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 10, 2, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (1, 11, 3, 1);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (10, 19, 1, 3);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (10, 20, 3, 3);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (3, 2, 2, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (3, 3, 1, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (3, 4, 3, 4);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (4, 12, 1, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (4, 13, 2, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (4, 14, 5, 2);
INSERT INTO orders (customer_id, food_id, quantity, status_id) VALUES (8, 10, 1, 1);

 

-- Step 3: Create View
CREATE OR REPLACE VIEW order_customer AS
SELECT 
	o.id, o.customer_id, fullname, address, phone_num, food_name, quantity, price, order_time, method, status
FROM orders o
JOIN customers c 
	ON o.customer_id = c.id
JOIN payment_method pm
	ON c.prefered_paymethod = pm.id
JOIN food f 
	ON o.food_id = f.id
JOIN order_status os 
	ON o.status_id = os.id
ORDER BY o.id
;

CREATE OR REPLACE VIEW order_store AS
SELECT 
	o.id, store_id, store_name, food_name, quantity, price, order_time, method, status
FROM orders o
JOIN customers c 
	ON o.customer_id = c.id
JOIN payment_method pm
	ON c.prefered_paymethod = pm.id
JOIN food f 
	ON o.food_id = f.id
JOIN stores s
	ON f.store_id = s.id
JOIN order_status os 
	ON o.status_id = os.id
ORDER BY o.id
;

CREATE OR REPLACE VIEW food_store AS
SELECT store_id, store_name, f.id AS food_id, food_name, price, ingredients
FROM food f
JOIN stores s
	ON f.store_id = s.id
ORDER BY s.id

-- 4 STORED PROCEDURES

DELIMITER $$
/* 1 view_customer_orders 
	- you provide a customer id 
    - I search and return any orders 
*/
CREATE PROCEDURE view_orders(IN p_id INT)
BEGIN
	SELECT * FROM order_customer WHERE customer_id = p_id;
END $$


/* 2 insert_new_customer
	- you provide fullname, address, phone_num, prefered_paymethod
    - I add you to customers table 
*/
CREATE PROCEDURE insert_new_customer(IN p_fullname VARCHAR(255), IN p_address VARCHAR(255), IN p_phone_num VARCHAR(255), IN p_prefered_paymethod INT)
BEGIN
 INSERT INTO customers (fullname, address, phone_num, prefered_paymethod) VALUES(p_fullname, p_address, p_phone_num, p_prefered_paymethod);
END $$


/* 3 delete_customer 
	- you provide customer id
    - I delete you from customers table
*/
CREATE PROCEDURE delete_customer(IN p_id INT)
BEGIN
	DELETE FROM customers WHERE id = p_id;
END $$


/* 4 update_customer_phone_num
	- you provide id and new phone number
    - I update customers table with new phone number
*/
CREATE PROCEDURE update_customer_phone(IN p_id INT, IN p_phone_num VARCHAR(255))
BEGIN
	UPDATE customers SET phone_num = p_phone_num WHERE id = p_id;
END $$


/* 5 update_customer_address
	- you provide id and new email
    - I update members table with new email
*/
CREATE PROCEDURE update_customer_address(IN p_id INT, IN p_address VARCHAR(255))
BEGIN
	UPDATE customers SET address = p_address WHERE id = p_id;
END $$


/* 6 make_order
	- you provide customer id, food id, and quantity
    - I add the orders
    - I update your payment due in the customers table
*/
CREATE PROCEDURE make_orders(IN p_customer_id INT, p_food_id INT, IN p_quantity INT)
BEGIN

	DECLARE v_payment_due DECIMAL(6, 2);
    DECLARE v_price DECIMAL(6, 2);

	SELECT payment_due INTO v_payment_due FROM customers WHERE id = p_customer_id;
    SELECT price INTO v_price FROM food WHERE id = p_food_id;

	INSERT INTO orders (customer_id, food_id, quantity) VALUES(p_customer_id, p_food_id, p_quantity);
	UPDATE customers SET payment_due = v_payment_due + v_price WHERE id = p_customer_id;
    
END $$

/* 7 complete_payment 
	- you provide order id
    - I deduct payment from payment due in customers table
*/

CREATE PROCEDURE complete_payment(IN p_order_id INT ,  OUT p_message VARCHAR(255))
BEGIN

    DECLARE v_balance DECIMAL(6,2);
    DECLARE v_price DECIMAL(6,2);
    DECLARE v_customer_id VARCHAR(255);

    SELECT customer_id, price INTO v_customer_id, v_price
		FROM order_customer
        WHERE id = p_order_id;
        
    SELECT payment_due INTO v_balance
		FROM customers
        WHERE id = v_customer_id;
        
    UPDATE orders SET status_id = 4 WHERE id = p_order_id;    
    UPDATE customers SET payment_due = v_balance - v_price WHERE id = v_customer_id;
	SELECT 'Thank you for you payment!' INTO p_message;

END $$

/* 8 cancel_orders 
	- you provide the order id
    - I check if you can still cancel
		- if yes, I change order status to cancelled in orders table and subtract price from your payment due
        - if no, I tell you it's too late to cancel
*/
CREATE PROCEDURE cancel_order(IN p_order_id INT, OUT p_message VARCHAR(255))
BEGIN
	DECLARE v_status VARCHAR(255);
	DECLARE v_balance DECIMAL(6,2);
    DECLARE v_price DECIMAL(6,2);
    DECLARE v_customer_id VARCHAR(255);
    
	SELECT status, customer_id, price INTO v_status, v_customer_id, v_price
    FROM order_customer
    WHERE id = p_order_id;

	SELECT payment_due INTO v_balance
	FROM customers
	WHERE id = v_customer_id;
	
	IF v_status = 'Delivering' OR v_status = 'Delivered' OR v_status = 'Cooking'
		THEN SELECT 'Sorry, this order cannot be cancelled now.' INTO p_message;
        ELSE 
			UPDATE orders SET status_id = 5 WHERE id = p_order_id;
            UPDATE customers SET payment_due = v_balance - v_price WHERE id = v_customer_id;
            SELECT 'Order cancelled!' INTO p_message;
	END IF; 
    
    
END $$


